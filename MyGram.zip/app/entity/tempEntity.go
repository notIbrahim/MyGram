package entity

type TemporaryEntity struct {
	User_ID  uint
	Photo_ID uint
}
